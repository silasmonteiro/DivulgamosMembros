package com.example.divulgamoskids

data class Contact (

    val nome: String,
    val ig: String,
    val dataEntrada: String,
    val dataSaida: String

)